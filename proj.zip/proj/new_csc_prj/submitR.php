<html>

<h1> Thank You for Registering </h1>



<?php

/*if(isset(n=$_POST)
{
   $id =$_POST;
}else{
  $id = "";
}*/

$x=$_POST['firstname'];

$y=$_POST['lastname'];

$z=$_POST['username'];

$e=$_POST['email'];

$n=$_POST['phone'];

$w=$_POST['password'];

$servername = "localhost";

$username = "root";

$password = "";

$dbname="reg";



//create connection

$conn = new mysqli($servername, $username, $password, $dbname);

 

//check connection

if ($conn->connect_error) {

                die("connection failed:" . $conn->connect_error);

}
/*
echo "";
 

$sql = "INSERT INTO `users` (`fname`, `lname`,`username`, `email`, `phone`, `password`)  VALUES('$x', '$y','$z','$e','$n','$w')"; 

*/ 

if ($conn->query($sql) === TRUE) {

                echo ".";

} else {

                echo "Error: " . $sql . "<br>" , $conn->error;

}
 

$conn->close();

?>
<br>
<br>

<p><font size ="12"><a href="memberLogin.html"> Member-Login-Here</a></font></p>
</html>

 

<?php

$x=$_POST['firstname'];

$y=$_POST['lastname'];

$z=$_POST['username'];

$e=$_POST['email'];

$n=$_POST['phone'];

$w=$_POST['password'];

$servername = "localhost";

$username = "root";

$password = "";

$dbname="reg";

 

//create connection

$conn = new mysqli($servername, $username, $password, $dbname);

 

//check connection

if ($conn->connect_error) {

                die("connection failed:" . $conn->connect_error);

}
 


 

$conn->close();

?>

 