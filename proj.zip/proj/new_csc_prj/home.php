<!DOCTYPE html>

<html>
<style>
div.a {
  text-align: center;
}

div.b {
  text-align: left;
}

body {
        background: white }
    section {
        background: black;
        color: white;
        border-radius: 1em;
        padding: 1em;
        position: absolute;
        top: 40%;
        left: 50%;
        margin-right: -50%;
        transform: translate(-50%, -50%) }
</style>

<head>

                <title> Registration </title>


</head>

<body>

<div class = "a"><h2>Registration form below: </h2>

 

<form action="submitR.php" method="post">

<section>
                <div class = "b">First Name:</div>

                <div class = "b"><input type="text" name="firstname" ></div>
                

               <div class = "b">Last Name:</div> 

                <div class = "b"><input type="text" name="lastname" ></div>
				
				<br>
				<br>
				<div class = "b">Email:</div>
				<div class = "b"><input type="text" name="email" ></div>
				
				<div class = "b">Phone Number:</div>
				<div class = "b"><input type="text" name="phone" ></div>
				
				<br>
				<br>
				<div class = "b">User Name: </div>
				<div class = "b"><input type="text" name="username"></div>
				
				<div class = "b"><th>Password:</div>
				<div class = "b"><input type="password" name="password"></div>
				<br>
				<br>
					<div class ="a">		<input type="submit" value="Submit"></div><br> 
				</section>
				
				<br>
				<br>

</div>
				
				
</form>

 

 

</body>

 

</html>



<?php
mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("reg") or die (mysql_error());

?>